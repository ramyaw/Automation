package com.groovy.objectExample

class ObjectExample1 {
	
	String name
	String place
	
	
	def methodOne() {
		println "Hello World"
 	}

}
