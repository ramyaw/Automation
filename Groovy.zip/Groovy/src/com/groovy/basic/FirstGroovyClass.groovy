package com.groovy.basic

class FirstGroovyClass {

	static void main(String[] args) {
		println "Hello Riche"
	}
}
