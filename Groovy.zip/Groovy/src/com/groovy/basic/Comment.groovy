
//#! /user/bin/groovy
//This comment should be the first line.
// This kind of comment is used in unix
// Pre requiste: Groovy should be installed 


// Single line Comment


/*
 * Multiline
 * Comment 
 */


println("Hello Riche")