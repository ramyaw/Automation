
def file = new File('newFileWrite.txt')

file.write('First Line')
file << 'Second line added'
file << 'third line also complete'