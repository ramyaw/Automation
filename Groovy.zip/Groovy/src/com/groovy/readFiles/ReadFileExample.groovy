
def file = new File('newFile.txt')
println file.text