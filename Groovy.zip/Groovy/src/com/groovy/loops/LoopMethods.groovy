
// upto

1.upto(4) {
	println "we are seeing example of upto method..."
}


// Step
1.step(6, 2) {
	// Prints the count of loop
	println "${it}"
}


3.times() {
	println "Example of times"
}