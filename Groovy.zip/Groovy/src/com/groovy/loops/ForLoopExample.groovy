

// For
for(def i=0; i<5; i++) {
	println "For Loop:" + i
}

//While
def j = 1
while(j<9) {
	println "While Loop:" + j
	j++;
}


// For Each
def myList = [1,2,3,4,5,6,7]
for(int temp: myList) {
	println "For Each Loop:" + temp
}
